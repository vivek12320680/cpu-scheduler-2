<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header("Content-Type: application/json");
    $algorithm = $_POST["algorithm"];
    $processData = str_replace("\\", "\n", trim($_POST["processData"]));
    $lines = explode("\n", $processData);

    $processes = [];
    foreach ($lines as $line) {
        $values = array_map('trim', explode(",", $line));
        if (count($values) === 3) {
            $processes[] = ["pid" => (int)$values[0], "arrival" => (int)$values[1], "burst" => (int)$values[2]];
        }
    }

    if (empty($processes)) {
        echo json_encode(["error" => "Invalid process data"]);
        exit;
    }

    $result = [];
    switch ($algorithm) {
        case "fcfs":
            $result = fcfs($processes);
            break;
        case "sjf":
            $result = sjf($processes);
            break;
        case "srtf":
            $result = srtf($processes);
            break;
        case "round_robin":
            $result = round_robin($processes, 2);
            break;
        default:
            $result = ["error" => "Invalid algorithm"];
    }

    echo json_encode($result);
}

function fcfs($processes) {
    usort($processes, fn($a, $b) => $a['arrival'] <=> $b['arrival']);
    $time = 0;
    $schedule = [];
    foreach ($processes as $process) {
        $start = max($time, $process['arrival']);
        $end = $start + $process['burst'];
        $schedule[] = ["pid" => $process['pid'], "start" => $start, "end" => $end];
        $time = $end;
    }
    return ["schedule" => $schedule];
}

function sjf($processes) {
    usort($processes, fn($a, $b) => $a['burst'] <=> $b['burst']);
    return fcfs($processes);
}

function srtf($processes) {
    return fcfs($processes); // Placeholder: Implement Preemptive Logic
}

function round_robin($processes, $quantum) {
    return fcfs($processes); // Placeholder: Implement RR Logic
}
?>
