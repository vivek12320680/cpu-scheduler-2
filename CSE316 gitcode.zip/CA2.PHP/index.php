<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CPU Scheduling Algorithms</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background: linear-gradient(120deg, #1e3c72, #2a5298);
            color: white;
            overflow: hidden;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            backdrop-filter: blur(10px);
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
        }
        textarea {
            width: 100%;
            height: 100px;
            font-size: 16px;
        }
        button {
            background: #ff9800;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }
        button:hover {
            background: #e68900;
        }
        select {
            padding: 8px;
            font-size: 16px;
        }
        #ganttChart {
            display: flex;
            margin-top: 20px;
            overflow-x: auto;
        }
        .gantt-block {
            min-width: 50px;
            padding: 10px;
            margin: 2px;
            background: #ffeb3b;
            color: black;
            border-radius: 5px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>CPU Scheduling Simulator</h1>
        <label for="algorithm">Choose Algorithm:</label>
        <select id="algorithm">
            <option value="fcfs">FCFS</option>
            <option value="sjf">SJF (Non-Preemptive)</option>
            <option value="srtf">SRTF (Preemptive SJF)</option>
            <option value="rr">Round Robin</option>
        </select>
        <input type="number" id="timeQuantum" placeholder="Time Quantum (RR)" style="display:none;">
        <br><br>
        <textarea id="processInput" placeholder="Enter process details (PID,Arrival,Burst)"></textarea>
        <br>
        <button onclick="calculateSchedule()">Calculate</button>
        <h2>Gantt Chart</h2>
        <div id="ganttChart"></div>
        <h2>Process Details</h2>
        <pre id="result"></pre>
    </div>

    <script>
        document.getElementById("algorithm").addEventListener("change", function() {
            document.getElementById("timeQuantum").style.display = (this.value === "rr") ? "inline-block" : "none";
        });

        function parseInput() {
            let input = document.getElementById("processInput").value.trim();
            let lines = input.split("\n");
            let processes = [];

            for (let line of lines) {
                let parts = line.split(",");
                if (parts.length !== 3) {
                    alert("Invalid input format! Use: PID,Arrival,Burst");
                    return [];
                }
                processes.push({
                    pid: parseInt(parts[0]),
                    arrivalTime: parseInt(parts[1]),
                    burstTime: parseInt(parts[2]),
                    remainingTime: parseInt(parts[2])
                });
            }
            return processes;
        }

        function fcfs(processes) {
            processes.sort((a, b) => a.arrivalTime - b.arrivalTime);
            let time = 0, schedule = [];
            processes.forEach(p => {
                let start = Math.max(time, p.arrivalTime);
                let end = start + p.burstTime;
                schedule.push({ pid: p.pid, start, end });
                time = end;
            });
            return schedule;
        }

        function sjf(processes) {
            let time = 0, schedule = [], completed = 0;
            while (completed < processes.length) {
                let available = processes.filter(p => p.arrivalTime <= time && p.remainingTime > 0);
                if (available.length === 0) { time++; continue; }
                available.sort((a, b) => a.burstTime - b.burstTime);
                let p = available[0];
                let start = time, end = start + p.burstTime;
                schedule.push({ pid: p.pid, start, end });
                time = end;
                p.remainingTime = 0;
                completed++;
            }
            return schedule;
        }

        function srtf(processes) {
            let time = 0, schedule = [], completed = 0;
            while (completed < processes.length) {
                let available = processes.filter(p => p.arrivalTime <= time && p.remainingTime > 0);
                if (available.length === 0) { time++; continue; }
                available.sort((a, b) => a.remainingTime - b.remainingTime);
                let p = available[0];
                schedule.push({ pid: p.pid, start: time, end: time + 1 });
                p.remainingTime--;
                time++;
                if (p.remainingTime === 0) completed++;
            }
            return schedule;
        }

        function roundRobin(processes, quantum) {
            let time = 0, queue = [...processes], schedule = [];
            while (queue.length > 0) {
                let p = queue.shift();
                if (p.remainingTime > quantum) {
                    schedule.push({ pid: p.pid, start: time, end: time + quantum });
                    p.remainingTime -= quantum;
                    time += quantum;
                    queue.push(p);
                } else {
                    schedule.push({ pid: p.pid, start: time, end: time + p.remainingTime });
                    time += p.remainingTime;
                    p.remainingTime = 0;
                }
            }
            return schedule;
        }

        function displayGanttChart(schedule) {
            let chart = document.getElementById("ganttChart");
            chart.innerHTML = "";
            schedule.forEach(s => {
                let div = document.createElement("div");
                div.className = "gantt-block";
                div.textContent = `P${s.pid}`;
                chart.appendChild(div);
            });
        }

        function calculateSchedule() {
            let processes = parseInput();
            if (processes.length === 0) return;
            let algo = document.getElementById("algorithm").value;
            let schedule;
            
            switch (algo) {
                case "fcfs": schedule = fcfs(processes); break;
                case "sjf": schedule = sjf(processes); break;
                case "srtf": schedule = srtf(processes); break;
                case "rr": schedule = roundRobin(processes, parseInt(document.getElementById("timeQuantum").value)); break;
            }
            displayGanttChart(schedule);
            document.getElementById("result").textContent = JSON.stringify(schedule, null, 2);
        }
    </script>
</body>
</html>
